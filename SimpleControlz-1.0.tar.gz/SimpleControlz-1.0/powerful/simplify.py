"""
    This module is a way of simplifing the way code is written.
    It offers a metaclass and two simplifier classes. These Simplifier classes
    allows you to create, access, change and maipulate data more easily.
    The 'Constructor' class allows for easy access and maipulation to return
    values mostly based on types. The 'Release' class allows for easy access to
    objects those objects may be able to create or change data to your liking
    for easier usage.

"""

class Easy(type):
    ''' This is a metaclass that contains guidelines for the Constructor class.''' 
    
    def __new__(cls, clsname, bases, clsdict):
        
        classnames = ["Constructor", "Construct", "Create", "Creator", "Maker", "Make"]
        
        if clsname not in classnames:
            print("Class names must be in {}".format(classnames))
        
        elif clsname in classnames:
            clsname = clsname
            
        newDict = {}
        methods = ["types", "strings", "integers", "booleans", "methods", "get", "struct"]
        
        for name, value in clsdict.items():
            if not name.startswith("__"):
                if callable(value) == True and value.__name__ not in methods:
                    print("Name must be in {}".format(methods))
                
                elif callable(value) == True and value.__name__ in methods:
                    newDict[name.lower()] = value
        
        obj = type(clsname, bases, newDict)
        return obj


class Constructor(metaclass=Easy):
    ''' This is a constructor class for structuring and easier access to values.'''
    
    
    def types(self, Types):
        ''' This method takes alist and returns a dictionary of types of all types.'''
        
        if type(Types) != list:
            Types = None
        
        elif type(Types) == list:
            
            for name in Types:
                if name not in [type, str, int, bool, list, dict, float, complex, set, object]:
                    Types = None
                
                elif name in [type, str, int, bool, list, dict, float, complex, set, object]:
                    Types = Types
        
        else:
            Types = None
        
        obj = {"Types":Types}
        return obj
    
    
    def strings(self, string):
        ''' This method takes a list of strings and returns that list.'''
        
        if type(string) != list:
            string = None
        
        elif type(string) == list:
            string = string
            
            for s in string:
                if type(s) != str:
                    string = None
                
                elif type(s) == str:
                    string = string
                
                else:
                    string = None
        
        return string
    
    
    def integers(self, integer):
        ''' This method takes a list of integers and returns that list.'''
        
        if type(integer) != list:
            integer = None
        
        elif type(integer) == list:
            integer = integer
            
            for i in integer:
                if type(i) != int:
                    integer = None
                
                elif type(i) == int:
                    integer = integer
                
                else:
                    integer = None
            
        return integer
    
    
    def booleans(self, boolean):
        ''' This method takes a list of booleans and returns that list.'''
        
        if type(boolean) != list:
            boolean = None
        
        elif type(boolean) == list:
            boolean = boolean
            
            for b in boolean:
                if type(b) != bool:
                    boolean = None
                
                elif type(b) == bool:
                    boolean = boolean
                
                else:
                    boolean = None
            
        return boolean
    
    
    def methods(self, method):
        ''' This method takes a list of functions / methods and returns that list.'''
        
        if type(method) != list:
            method = None
        
        elif type(method) == list:
            method = method
            
            for m in method:
                if callable(m) == False or type(m).__name__ != 'function':
                    method = None
                
                elif callable(m) == True or type(m).__name__ == 'function':
                    method = method
                
                else:
                    method = None
        
        return method
    
    
    def get(self, string, integer=None, boolean=None, method=None):
        ''' This method takes one or more constructor methods and returns
            a dictionary containing those methods.
        '''
                           
        if type(string) != list:
            string = None
        
        elif type(string) == list:
            string = string
            
            for s in string:
                if type(s) != str:
                    string = None
                
                elif type(s) == str:
                    string = string
                
                else:
                    string = None
        
        if integer is not None and type(integer) != list:
            integer = None
        
        elif integer is not None and type(integer) == list:
            integer = integer
            
            for i in integer:
                if type(i) != int:
                    integer = None
                
                elif type(i) == int:
                    integer = integer
                
                else:
                    integer = None
        
        if boolean is not None and type(boolean) != list:
            boolean = None
        
        elif boolean is not None and type(boolean) == list:
            boolean = boolean
            
            for name in boolean:
                if name != True or name != False:
                    name = None
                
                elif name == True or name == False:
                    boolean = boolean
                
                else:
                    boolean = None
        
        if method is not None and type(method) != list:
            method = None
        
        elif method is not None and type(method) == list:
            method = method
            
            for m in method:
                if callable(m) == False or type(m).__name__ not in ['method', 'function']:
                    method = None
            
                elif callable(m) == True or type(m).__name__ in ['method', 'function']:
                    method = method
        
        obj = {"strings":string, "integers":integer, "booleans":boolean, "methods":method}
        return obj
    
    
    def struct(self, lists, sfunc, ifunc, bfunc, mfunc):
        ''' This method takes a list that contians lists holding values
            that are specific to the (strings, integers, booleans, and methods)
            functions and returns a dictionary. The {keys} are the functions and the
            {:values} are the lists specific to each method.
        '''
        
        obj = None
        s, i, b, m = None, None, None, None
        
        if type(lists) != list and len(lists) != 4:
            lists = None
        
        elif type(lists) == list and len(lists) == 4:
            
            for l in lists[0]:
                if type(l) != str:
                    break
                
                elif type(l) == str:
                    s = lists[0]
                    break
            
            for a in lists[1]:
                if type(a) != int:
                    break
                
                elif type(a) == int:
                    i = lists[1]
                    break
            
            for c in lists[2]:
                if type(c) != bool:
                    break
                
                elif type(c) == bool:
                    b = lists[2]
                    break
            
            for d in lists[3]:
                if callable(d) == False:
                    break
                
                elif callable(d) == True:
                    m = lists[3]
            
        else:
            return obj
    
        obj = {sfunc:s, ifunc:i, bfunc:b, mfunc:m}
        
        return obj


        

class Release(object):
    ''' This class is specifically for objects and the returning / releasing
        of those objects. All objects are relative to the 'Constructor' class!
    '''
    
    def __init__(self, constructor, strings=None, integers=None, booleans=None, methods=None, get=None, struct=None):
        self.constructor = constructor
        self.strings = strings
        self.integers = integers
        self.booleans = booleans
        self.methods = methods
        self.get = get
        self.struct = struct
    
    
    def objects(self):
        ''' This method is for returning the objects. A dictionary containing
            a list of objects. The {key} is a string with the name 'Objects' and
            the {:value} is the list of objects. Again all objects are relative to
            the 'Constructor' class!
        '''
        
        if self.constructor.__name__ != 'Constructor':
            self.constructor = None
        
        elif self.constructor.__name__ == 'Constructor':
            self.constructor = self.constructor
        
        if self.strings is not None and self.strings.__name__ != 'strings':
            self.strings = None
        
        elif self.strings is not None and self.strings.__name__ == 'strings':
            self.strings = self.strings
        
        if self.integers is not None and self.integers.__name__ != 'integers':
            self.integers = None
        
        elif self.integers is not None and self.integers.__name__ == 'integers':
            self.integers = self.integers
        
        if self.booleans is not None and self.booleans.__name__ != 'booleans':
            self.booleans = None
        
        elif self.booleans is not None and self.booleans.__name__ == 'booleans':
            self.booleans = self.booleans
        
        if self.methods is not None and self.methods.__name__ != 'methods':
            self.methods = None
        
        elif self.methods is not None and self.methods.__name__ == 'methods':
            self.methods = self.methods
        
        if self.get is not None and self.get.__name__ != 'get':
            self.get = None
        
        elif self.get is not None and self.get.__name__ == 'get':
            self.get = self.get
        
        if self.struct is not None and self.struct.__name__ != 'struct':
            self.struct = None
        
        elif self.struct is not None and self.struct.__name__ == 'struct':
            self.struct = self.struct
        
        
        obj = {"Objects":[self.constructor, self.strings, self.integers, self.booleans, self.methods, self.get, self.struct]}
        return obj
        

def returns():
    ''' This function simply uses the 'Release' class to return all the objects
        of the 'Constructor' class without the extra work.
    '''
    
    constructor = Constructor
    strings = Constructor().strings
    integers = Constructor().integers
    booleans = Constructor().booleans
    methods = Constructor().methods
    get = Constructor().get
    struct = Constructor().struct
    
    release = Release(constructor, strings, integers, booleans, methods, get, struct)
    objects = release.objects()
    
    return objects

