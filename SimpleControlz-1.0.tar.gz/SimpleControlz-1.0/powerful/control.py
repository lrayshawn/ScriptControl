'''
    This module is useful for calling functions and methods.
    The 'control.py' module contains several ways for calling
    methods and functions and several ways to access that data.
'''


class Call(object):
    '''This is the 'Call' class which has methods that caters to both
       *single* calls and *multiple* callings.
    '''
    
    def __init__(self, functions, values=None):
        self.functions = functions
        self.values = values
        self.pcalled = []
        self.scalled = []
    
    
    def primary(self):
        '''This is the 'primary' method which allows *single* 'method / function'
           calls or *single* 'function / method value' calls.
        '''
        
        if type(self.functions) != list and type(self.values) != list:
            if callable(self.functions) == False:
                self.functions = None
                self.values = None
                return "Not a valid function / method!"
            
            elif callable(self.functions) == True and self.values is None:
                self.pcalled.append(self.functions())
            
            elif callable(self.functions) == True and self.values is not None:
                self.pcalled.append(self.functions(self.values))
            
            elif callable(self.functions) == True and self.values is not None:
                if callable(self.values) == True:
                    self.pcalled.append(self.functions(self.values()))
        
        return self.pcalled
    
    
    def secondary(self):
        '''This is the 'secondary' method which allows *multiple* 'function / method
           calls' or *multiple* 'function / method value' calls. All functions / methods
           and values *must* be in a *list*: ex. [functions / methods], [values]. The
           *lists* *must* be the *same* 'length'.
        '''
        
        if type(self.functions) == list and type(self.values) == list:
            if len(self.functions) == 0:
                self.functions = None
                self.values = None
                self.scalled = [self.functions, self.values]
            
            elif len(self.functions) > 0 and len(self.values) == 0:
                for func in self.functions:
                    if callable(func) == False:
                        self.functions = None
                        self.scalled = [self.functions, self.values]
                    
                    elif callable(func) == True:
                        self.scalled.append(func())
            
            elif len(self.functions) > 0 and len(self.values) > 0:
                if len(self.functions) == len(self.values):
                
                    for func in self.functions:
                        for val in self.values:
                            if callable(func) == False:
                                self.functions = None
                                self.values = None
                                self.scalled = [self.functions, self.values]
                            
                            elif callable(func) == True and callable(val) == False:
                                self.scalled.append(func(val))
                                
                            
                            elif callable(func) == True and callable(val) == True:
                                self.scalled.append(func(val()))
                        break                
                
                elif len(self.functions) != len(self.values):
                    self.functions = None
                    self.values = None
                    self.scalled = [self.functions, self.values]
                    
            
        elif type(self.functions) == list and self.values == None:
                
                for func in self.functions:
                    if callable(func) == False:
                        self.functions = None
                        self.scalled = [self.functions, self.values]
                    
                    elif callable(func) == True:
                        self.scalled.append(func())                         
                      
        
        return self.scalled


class Caller(object):
    '''The 'Caller' class is *specifically* for all types of function / method calls.'''
    
    def __init__(self, function):
        self.function = function
        self.called = []
    
    def __call__(self, *args, **kwargs):
        self.called.append(self.function(*args, **kwargs))
        
        return self.called

@Caller
def caller(func, value):
    '''The 'caller' method is 'decorated' using the 'Caller' class. It allows for
       simple *single* 'function / method value' calls.
    '''

    if callable(func) == False:
        func = None
        value = None
    
    elif callable(func) == True and callable(value) == False:
        return func(value)
    
    elif callable(func) == True and callable(value) == True:
        return func(value())


@Caller
def functions(funcs):
    '''The 'functions' method is decorated using the 'Caller' class. It allows for
       a *list* of 'functions / methods' to be called. *functions / methods only*.
    '''
    
    called = []
    
    if type(funcs) != list:
        funcs = None
    
    elif type(funcs) == list:
        
        for func in funcs:
            if callable(func) == False:
                func = None
            
            elif callable(func) == True:
                called.append(func())
    
    obj = {"functions":called}
    return obj

