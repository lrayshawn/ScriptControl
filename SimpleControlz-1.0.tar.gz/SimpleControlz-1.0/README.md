
A way to control script functionality.

ScriptControl actually has two modules: 'simplify.py' and 'control.py'.
These modules allow for the creation, access, and manipulation of objects, functions and types like (str, int etc.)
The modules are basic and anyone could have written them and probally have but,
i wanted to help prevent writting so much code and bombarding the script so,
i wrote them.

They are easy to use and provides several ways of accessing data.