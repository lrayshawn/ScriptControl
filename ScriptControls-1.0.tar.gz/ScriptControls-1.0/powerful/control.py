class Caller(object):
    
    def __init__(self, function):
        self.function = function
        self.called = []
    
    def __call__(self, *args, **kwargs):
        self.called.append(self.function(*args, **kwargs))
        
        return self.called

@Caller
def caller(func, value):

    if callable(func) == False:
        func = None
        value = None
    
    elif callable(func) == True and callable(value) == False:
        return func(value)
    
    elif callable(func) == True and callable(value) == True:
        return func(value())


@Caller
def functions(funcs):
    
    called = []
    
    if type(funcs) != list:
        funcs = None
    
    elif type(funcs) == list:
        
        for func in funcs:
            if callable(func) == False:
                func = None
            
            elif callable(func) == True:
                called.append(func())
    
    obj = {"functions":called}
    return obj


class Call(object):
    
    def __init__(self, functions, values=None):
        self.functions = functions
        self.values = values
        self.pcalled = []
        self.scalled = []
    
    
    def primary(self):
        
        if type(self.functions) != list and type(self.values) != list:
            if callable(self.functions) == False:
                self.functions = None
                self.values = None
                return "Not a valid function / method!"
            
            elif callable(self.functions) == True and self.values is None:
                self.pcalled.append(self.functions())
            
            elif callable(self.functions) == True and self.values is not None:
                self.pcalled.append(self.functions(self.values))
            
            elif callable(self.functions) == True and self.values is not None:
                if callable(self.values) == True:
                    self.pcalled.append(self.functions(self.values()))
        
        return self.pcalled
    
    
    def secondary(self):
        pos1 = 0
        pos2 = 0
        
        if type(self.functions) == list and type(self.values) == list:
            if len(self.functions) == 0:
                self.functions = None
                self.values = None
                self.scalled = [self.functions, self.values]
            
            elif len(self.functions) > 0 and len(self.values) == 0:
                for func in self.functions:
                    if callable(func) == False:
                        self.functions = None
                        self.scalled = [self.functions, self.values]
                    
                    elif callable(func) == True:
                        self.scalled.append(func())
            
            elif len(self.functions) > 0 and len(self.values) > 0:
                if len(self.functions) == len(self.values):
                
                    for func in self.functions:
                        for val in self.values:
                            if callable(func) == False:
                                self.functions = None
                                self.values = None
                                self.scalled = [self.functions, self.values]
                            
                            elif callable(func) == True and callable(val) == False:
                                self.scalled.append(func(val))
                                
                            
                            elif callable(func) == True and callable(val) == True:
                                self.scalled.append(func(val()))
                        break                
                
                elif len(self.functions) != len(self.values):
                    self.functions = None
                    self.values = None
                    self.scalled = [self.functions, self.values]
                    
            
        elif type(self.functions) == list and self.values == None:
                
                for func in self.functions:
                    if callable(func) == False:
                        self.functions = None
                        self.scalled = [self.functions, self.values]
                    
                    elif callable(func) == True:
                        self.scalled.append(func())                         
                      
        
        return self.scalled




